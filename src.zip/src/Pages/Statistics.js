import Navbar01 from '../Components/Nav';

import React from 'react';
import Table_data from '../Components/Teble';
const Statistics = () => {
    return (
        <div>
            <div>
                <Navbar01 />
                <Table_data />
            </div>

        </div>
    )
}
export default Statistics
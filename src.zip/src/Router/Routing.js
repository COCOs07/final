// นำเข้า React library ซึ่งจำเป็นสำหรับการสร้างคอมโพเนนต์ใน React
import React from "react";

// นำเข้าฟังก์ชัน `createBrowserRouter` และคอมโพเนนต์ `RouterProvider` 
// จาก react-router-dom library เพื่อจัดการระบบ routing
import { createBrowserRouter, RouterProvider } from "react-router-dom";

// นำเข้าคอมโพเนนต์เพจต่างๆ ที่จะใช้ในการแสดงผลตามเส้นทางต่างๆ
import Home from "../Pages/Home";
import History from "../Pages/History";
import Statistics from "../Pages/Statistics";
import Login from "../Pages/Login";
import Signup from "../Pages/Signup";

// สร้าง router object โดยใช้ `createBrowserRouter` 
// กำหนดเส้นทาง (path) และคอมโพเนนต์ที่จะแสดงผลเมื่อเข้าถึงเส้นทางนั้นๆ
const router = createBrowserRouter([
  {
    path: "/", // เส้นทาง root (เช่น http://localhost:3000/)
    element: <Home />, // แสดงคอมโพเนนต์ Home เมื่อเข้าถึงเส้นทาง root
  },
  {
    path: "/History", // เส้นทาง /History
    element: <History />, // แสดงคอมโพเนนต์ History เมื่อเข้าถึงเส้นทาง /History
  },
  {
    path: "/Statistics", // เส้นทาง /Statistics
    element: <Statistics />, // แสดงคอมโพเนนต์ Statistics เมื่อเข้าถึงเส้นทาง /Statistics
  },
  {

    path: "/Login", // เส้นทาง /login
    element: <Login />, // แสดงคอมโพเนนต์ login เมื่อเข้าถึงเส้นทาง /login
  },
  {

    path: "/Signup", // เส้นทาง /Signup
    element: <Signup />, // แสดงคอมโพเนนต์ login เมื่อเข้าถึงเส้นทาง /login
  },
]);

// สร้าง functional component ชื่อ Routing
const Routing = () => {
  // ส่วนนี้คือสิ่งที่จะถูก render (แสดงผล) บนหน้าจอ
  return (
    // React Fragments ใช้สำหรับจัดกลุ่ม element หลายๆ อันโดยไม่สร้าง node เพิ่มใน DOM จริง
    <>
      {/* เรียกใช้คอมโพเนนต์ RouterProvider และส่ง router object ที่สร้างไว้เป็น prop */}
      <RouterProvider router={router} />
    </>
  );
};

// export คอมโพเนนต์ Routing เพื่อให้ส่วนอื่นๆ ของแอปพลิเคชันสามารถนำไปใช้งานได้
export default Routing;
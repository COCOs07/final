// นำเข้าคอมโพเนนต์ต่างๆ จาก react-bootstrap library
import Container from 'react-bootstrap/Container'; // สำหรับสร้าง container 
import Nav from 'react-bootstrap/Nav'; // สำหรับสร้าง navigation bar
import Navbar from 'react-bootstrap/Navbar'; // สำหรับสร้าง navigation bar

// นำเข้า LinkContainer จาก react-router-bootstrap 
// เพื่อสร้างลิงก์ที่ทำงานร่วมกับ react-router ได้
import { LinkContainer } from 'react-router-bootstrap';

// สร้าง functional component ชื่อ Navbar_01
function Navbar_01() {
  return (
    <>
      {/* ใช้ React Fragment เพื่อจัดกลุ่ม elements */}
      {/* สร้าง Navbar */}
      <Navbar className='shadow' bg="dark" data-bs-theme="dark">
        {/* สร้าง Container ภายใน Navbar */}
        <Container>
          {/* สร้างลิงก์ไปยังหน้าหลัก */}
          <LinkContainer to="/">
            {/* สร้าง Nav ภายใน Navbar */}
            <Navbar.Brand href="#home">หน้าหลัก</Navbar.Brand>
          </LinkContainer>
          {/* สร้างลิงก์ไปยังหน้าสถิติ */}
          <Nav className="me-auto">
            <LinkContainer to="/Statistics">
              <Nav.Link href="#features">สถิติ</Nav.Link>
            </LinkContainer>
            {/* สร้างลิงก์ไปยังหน้าประวัติ */}
            <LinkContainer to="/History">
              <Nav.Link href="#pricing">ประวัติ</Nav.Link>
            </LinkContainer>
            {/* สร้างลิงก์ไปยังหน้าเข้าสู่ระบบ */}
            <LinkContainer to="/Login">
              <Nav.Link href="#pricing">เข้าสู่ระบบ</Nav.Link>
            </LinkContainer>
            <LinkContainer to="/Signup">
              <Nav.Link href="#pricing">ลงทะเบียน</Nav.Link>
            </LinkContainer>
          </Nav>
        </Container>
      </Navbar>
    </>
  );
}

// export คอมโพเนนต์ Navbar_01 เพื่อให้ส่วนอื่นๆ ของแอปพลิเคชันสามารถนำไปใช้งานได้
export default Navbar_01;
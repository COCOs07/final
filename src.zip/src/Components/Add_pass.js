import styled from "styled-components";
import React, { useState } from 'react';
import { database, ref, set, get } from '../Firebase/Firebase';  // Import `get` from Firebase
import Swal from 'sweetalert2';

const Add_pass = () => {
  const handleAddPassenger = () => {
    Swal.fire({
      title: 'เพิ่มผู้โดยสาร',
      html: `
        <input id="swal-input1" class="swal2-input" placeholder="ชื่อผู้โดยสาร">
        <select id="swal-input2" class="swal2-input">
          <option value="">เลือกที่นั่ง</option>
          ${Array.from({ length: 7 }, (_, i) => i + 1).map(seatNumber =>
        `<option value="${seatNumber}">${seatNumber}</option>`
      ).join('')}
        </select>
      `,
      focusConfirm: false,
      preConfirm: () => {
        const passengerName = document.getElementById('swal-input1').value;
        const seatNumber = document.getElementById('swal-input2').value;
        if (!passengerName || !seatNumber) {
          Swal.showValidationMessage('กรุณากรอกชื่อผู้โดยสารและเลือกที่นั่ง');
        }
        return [passengerName, seatNumber];
      }
    }).then((result) => {
      if (result.isConfirmed) {
        const [passenger, seatNumber] = result.value;

        // สร้าง reference ไปยัง node ของที่นั่ง
        const seatRef = ref(database, `passengers/seat_${seatNumber}`);

        // ตรวจสอบที่นั่งว่าใช้งานไปแล้วหรือยัง
        get(seatRef).then((snapshot) => {  // Use get() here
          if (snapshot.exists()) {
            Swal.fire('มีผู้โดยสารอยู่ที่ที่นั่งนี้แล้ว', 'กรุณาเลือกที่นั่งอื่น', 'warning');
          } else {
            // บันทึกชื่อผู้โดยสารลงในที่นั่ง
            set(seatRef, { name: passenger })
              .then(() => {
                Swal.fire('เพิ่มผู้โดยสารสำเร็จ!', '', 'success');
              })
              .catch((error) => {
                console.error("Error adding passenger: ", error);
                Swal.fire('เกิดข้อผิดพลาด', 'ไม่สามารถเพิ่มผู้โดยสารได้', 'error');
              });
          }
        }).catch((error) => {
          console.error("Error checking seat availability: ", error);
          Swal.fire('เกิดข้อผิดพลาด', 'ไม่สามารถตรวจสอบที่นั่งได้', 'error');
        });
      }
    });
  };

  return (
    <StyledWrapper>
      <button onClick={handleAddPassenger}>
        <span>+ 
          <svg height="24" width="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" /> ผู้โดยสาร
        </span>
      </button>
    </StyledWrapper>
  );
};

const StyledWrapper = styled.div`
  button {
    border: 2px solid #24b4fb;
    background-color: #24b4fb;
    border-radius: 0.9em;
    cursor: pointer;
    padding: 0.8em 1.2em 0.8em 1em;
    transition: all ease-in-out 0.2s;
    font-size: 16px;
  }

  button span {
    display: flex;
    justify-content: center;
    align-items: center;
    color: #fff;
    font-weight: 600;
  }

  button:hover {
    background-color: #0071e2;
  }
`;

export default Add_pass;
